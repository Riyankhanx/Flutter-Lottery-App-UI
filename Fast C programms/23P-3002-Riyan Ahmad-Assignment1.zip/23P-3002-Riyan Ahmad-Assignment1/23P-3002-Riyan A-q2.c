#include <stdio.h>
#include <stdlib.h>

int prime(int);
int main()
{
    int num;
    printf("Enter a number\n");
    scanf("%d",&num);
 prime(num);
    return 0;
}
int prime(int n){
    int num,i,count=0;
    for(i=2;i<=num/2;i++)
    {
        if(num%i==0)
        {
        count=1;
        break;
        }
    }

    if(count==0)
    printf("\nNumber is prime") ;
    else 
       printf("\nNumber is not prime");
     
}

