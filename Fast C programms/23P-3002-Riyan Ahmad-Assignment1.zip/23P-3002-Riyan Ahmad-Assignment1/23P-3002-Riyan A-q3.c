#include <stdio.h>
void Maximized_storage(int,int);
int main() {

 int x,y;
  Maximized(x,y);

    return 0;
}
void Maximized(int x,int y){
       int costX=10,spaceX=6,volumeX=8;
       int costY=20,spaceY=8,volumeY=12,budget=140,maxSpace=72;
    int optimalX=0,optimalY=0,maxVolume=0;
    for (int numX=0;numX*spaceX<=maxSpace&&numX*costX<=budget; numX++) {
        int remainingBudget=budget-numX*costX;
        int maxNumY=remainingBudget/costY;
        for (int numY=0;numY<=maxNumY;numY++) {
            
            int totalVolume=numX*volumeX+numY*volumeY;
            if (totalVolume>maxVolume) {
                optimalX=numX;
                optimalY=numY;
                maxVolume=totalVolume;
            }
        }
    }
    printf("Optimal no. of Cabinet X: %d\n",optimalX);
    printf("Optimal no. of Cabinet Y: %d\n",optimalY);
    printf("Maximized volume: %d cubic feet\n",maxVolume);
}
