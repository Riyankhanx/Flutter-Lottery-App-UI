#include <stdio.h>
int letter_To_D(char l);
int main() {
    char letter;
    printf("Enter a letter:");
    scanf(" %c",&letter);
    printf("The letter you entered is:%c",letter);
    int digit =letter_To_D(letter);
    if (digit !=-1) {
        printf("\nThe corresponding telephone %c is: %d",letter,digit);
    } 
    else
        if(letter=='#'){
        printf("\nInvalid input.");
    }
    return 0;
}
int letter_To_D(char l) {
    switch (l) {
        case'A':case'B':case'C':
        return 2;
        case'D':case'E':case'F':
        return 3;
        case'G':case'H':case'I':
        return 4;
        case'J':case'K':case'L':
        return 5;
        case'M':case'N':case'O':
        return 6;
        case'P':case'Q':case'R':case 'S':
        return 7;
        case'T':case'U':case'V':
            return 8;
        case'W':case'X':case'Y':case'Z':
            return 9;
        default:
            return -1; 
    }
}
