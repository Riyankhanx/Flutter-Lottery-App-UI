#include <stdio.h>
int Total_c(int,int,int,int,int);
int main() {
 int a,b,c,d,e;
 int result;
 result=Total_c(a,b,c,d,e);
 printf("Result is %d",result);
    return 0;
}
int Total_c(int total_cookies,int num_cookies_in_box,int num_boxes_in_container,int  leftover_cookies,int leftover_boxes){
    printf("Enter the total number of cookies: ");
    scanf("%d", &total_cookies);
    printf("Enter the number of cookies in a box: ");
    scanf("%d",&num_cookies_in_box);
    printf("Enter the number of cookie boxes in a container:");
    scanf("%d",&num_boxes_in_container);
    leftover_cookies=total_cookies %num_cookies_in_box;
    int full_boxes=total_cookies/num_cookies_in_box;
    leftover_boxes=full_boxes%num_boxes_in_container;
    int full_containers=full_boxes/num_boxes_in_container;
    printf("Number of full boxes: %d\n",full_boxes);
    printf("Number of full containers: %d\n",full_containers);
    printf("Number of leftover cookies:%d\n",leftover_cookies);
    printf("Number of leftover boxes: %d\n",leftover_boxes);
    
}