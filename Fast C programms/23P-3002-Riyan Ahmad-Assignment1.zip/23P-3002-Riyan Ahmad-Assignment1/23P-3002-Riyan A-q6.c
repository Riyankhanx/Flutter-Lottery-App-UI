#include <stdio.h>
#include <stdlib.h>

void triangle(float,float,float);
int main()
{
    float S1,S2,S3;
    printf("Enter value of three sides\n");
    scanf("%f%f%f",&S1,&S2,&S3);
    triangle(S1,S2,S3);
    return 0;
}
void triangle(float a,float b,float c){
    if(a==b&&b==c&&c==a){
        printf("Triangle is isosceles\n");
    }
    else
     if(a==b&&b=c) {
        printf("Triangle is equilateral\n");
    }
    else
    if(a!=b &&b!=c&&c!=a){
      printf("Triangle is scalene\n");
    }


}
