#include <stdio.h>
#include <stdlib.h>
int Binary_to_Decimal(int);
int main()
{
    int binary_n,conversion;
    printf("Enter binary number\n");
    scanf("%d",&binary_n);
     conversion=Binary_to_Decimal(binary_n);
    printf("The required conversion is:%d",conversion);
   return 0;
}
int Binary_to_Decimal(int num){

int decimalnum=0,reminder,base=1;
while(num>0){
    reminder=num%10;
    decimalnum=decimalnum+reminder*base;
    num=num/10;
    base=base*2;
 }
return decimalnum;
}
