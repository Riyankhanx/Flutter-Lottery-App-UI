#include <stdio.h>
void Pi_value(int);
int main() {
int p;
Pi_value(p);
    return 0;
}
void Pi_value(int n){
    int number;
    float pi_approximate=0.0;
    printf("Enter the number of terms for approximation:");
    scanf("%d",&number);
    for (int i=0;i<number;number++) {
        double term=1.0/(2*i+1);
        pi_approximate=pi_approximate+(i%2&1)?term:-term;
    }
    pi_approximate=pi_approximate*4;
    printf("Approximate value of pi is: %.2f\n",number,pi_approximate);
}
