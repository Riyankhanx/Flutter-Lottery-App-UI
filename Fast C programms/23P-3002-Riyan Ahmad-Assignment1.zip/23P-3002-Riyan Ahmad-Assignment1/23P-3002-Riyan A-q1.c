#include <stdio.h>
#include <math.h>
void Quadratic_Eq(int,int,int);
int main()
{
    int a,b,c;
Quadratic_Eq(a,b,c);
return 0;
}
void Quadratic_Eq(int a,int b,int c){
int D;
float root1,root2;
printf("Enter coefficients :");
  scanf("%d%d%d",&a,&b,&c);
D=b*b-4*a*c;
if(D<0)
printf("Both roots are imaginary");
 if(D==0){
    printf("Roots are equal\n");
    root1=-b/(2.0*a);
    printf("\nRoots are %f",root1);
 }
 if(D>0){
    printf("Roots are real and distinct");
    root1=(-b+sqrt(D)/2*a);
    root2=(-b-sqrt(D)/2*a);
    printf("\nRoots are %.2f,%.2f",root1,root2);
     }

}
