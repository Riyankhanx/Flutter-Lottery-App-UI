#include<stdio.h>
#include<stdlib.h>
void printmenue();
int main()
{
    int ch;
    do{
       printmenue();
       printf("Enter your choice: ");
       scanf("%d",&ch);
        actionMenue(ch);
    }while(ch!=5);
    return 0;
}
void printmenue(){
printf("Menue\n");
printf("1.Add\n");
printf("2.Subtract\n");
printf("3.Multiply\n");
printf("4.Divide\n");
printf("5.Exit\n");
}
void actionMenue(int ch){
float num1,num2;
switch(ch){
case 1:
printf("Enter two numbers to add ");
scanf("%f%f",&num1,&num2);
printf("Add is %f\n",num1+num2);
break;
case 2:
printf("Enter two numbers to subtract ");
scanf("%f%f",&num1,&num2);
printf("Subtract is %f\n",num1-num2);
case 3:
printf("Enter two numbers to multiply ");
scanf("%f%f",&num1,&num2);
printf("Multiplication is %f\n",num1*num2);
case 4:
printf("Enter two numbers to divide ");
scanf("%f%f",&num1,&num2);
printf("Division is %f\n",num1/num2);
case 5:
printf("Exiting...");
break;
default:
printf("Invalid  try again");
}
}


