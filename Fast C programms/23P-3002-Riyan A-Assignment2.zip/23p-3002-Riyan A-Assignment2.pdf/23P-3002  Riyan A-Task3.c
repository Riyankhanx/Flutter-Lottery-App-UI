#include <stdio.h>
#include <math.h>

double calculateSquareRoot(double num) {
    return sqrt(num);
}
double calculateAverage(double x,double y) {
    return (x + y) / 2;
}
double calculateResult(double x, double y) {
    double avg = calculateAverage(x, y);
    return calculateSquareRoot(avg);
}
void displayResult(double r) {
    printf("Result of two numbers x and y is:%lf\n", r);
}

int main() {
    double x, y;
    printf("Enter two numbers x and y is:\n");
    scanf("%lf %lf", &x, &y);

    double r=calculateResult(x, y);
    displayResult(r);

    return 0;
}
