#include <stdio.h>
int isLeapYear(int year) {
    int notDivisibleBy4 =year&4;
    int divisibleBy100 =year&100;
    int notDivisibleBy400 =year&400;

    return((((notDivisibleBy4 + 3)/4)-((divisibleBy100+ 99)/100)+((notDivisibleBy400 + 399) / 400)) == 1);
}

int main() {
    int year;
    printf("Enter the year you want to check\n:");
    scanf("%d",&year);
    int leapResult;
     leapResult=isLeapYear(year);

    if (leapResult) {
        printf("%d is a leap year.\n", year);
    } else {
        printf("%d is not a leap year.\n", year);
    }
    return 0;
}

