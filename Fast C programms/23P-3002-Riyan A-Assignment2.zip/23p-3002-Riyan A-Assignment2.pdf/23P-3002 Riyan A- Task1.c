#include <stdio.h>
int IsLower(char c) {
    return (c - 'a' + 1)*(c - 'z' - 25) <= 0;
}
int IsUpper(char c) {
    return (c - 'A' + 1)*(c - 'Z' - 25) <= 0;
}

int main() {
    char ch;
    printf("Enter a character: ");
    scanf(" %c", &ch);
    if (IsLower(ch)) {
        printf("The character %c is a lower case alphabet.\n", ch);
   }
	 else
        if(IsUpper(ch)) {
        printf("The character %c is an upper case alphabet.\n", ch);
     }
    else {
        printf("The character %c is not an alphabet.\n", ch);
    }
    return 0;
}

