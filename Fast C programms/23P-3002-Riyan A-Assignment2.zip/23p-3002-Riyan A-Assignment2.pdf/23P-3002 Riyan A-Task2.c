#include <stdio.h>
double pounds_to_kg(double mass_pounds) {
    return mass_pounds * 0.453;
}

double feet_and_inches_to_meters(int height_feet, int height_inches) {
    int total_inches = height_feet * 12 + height_inches;
    return total_inches * 0.0254;
}

double calculate_bmi(double mass_kg, double height_meters) {
    return mass_kg / (height_meters * height_meters);
}
void display_bmi_info(double mass_kg, double height_meters, double bmi) {
    printf("Mass: %.2f kg\n", mass_kg);
    printf("Height: %.2f meters\n", height_meters);
    printf("BMI: %.2f\n", bmi);
}

int main() {

    double mass_pounds=121.254;
    int height_feet=5;
    int height_inches=5;

    double mass_kg=pounds_to_kg(mass_pounds);

    double height_meters=feet_and_inches_to_meters(height_feet, height_inches);


    double bmi=calculate_bmi(mass_kg, height_meters);

    display_bmi_info(mass_kg, height_meters,bmi);

    return 0;
}
