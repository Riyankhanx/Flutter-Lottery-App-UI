#include <stdio.h>
#include <stdlib.h>
//void Diamond(int ,int,int);
int main()
{
    int i,j,n;
    printf("Enter number of rows");
    scanf("%d",&n);
       for(int i=0;i<n;i++)
        {
       for(int j=0;j<n+i;j++)
       {
           if(j<n-1-1)

            printf("  ");
            else
                printf("*");
            }
        printf("\n");
       }


    return 0;
}



