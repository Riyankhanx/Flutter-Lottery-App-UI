#include <stdio.h>
int Perfect_num(int);
int main() {
    int k;
    printf("The perfect numbers between 1 and 500 are:\n");
    for (k=1;k<=500;k++) {
        if(Perfect_num(k)==k) {
            printf("%d\n",k);
        }
    }
    return 0;
}
int Perfect_num(int n){
    int sum= 0,i;
    for (i=1;i<=n/2;i++) {
        if (n%i==0) {
            sum=sum+i;
        }
    }
return sum;

}
