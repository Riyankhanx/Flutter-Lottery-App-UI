#include <stdio.h>
#include <math.h>
void pattern1(int,int);
void pattern2(int,int);
void pattern3(int,int);
void pattern4(int,int);
int main()
{
   int a,b;
   int c,d;
   pattern1(a,b);
   pattern2(c,d);
    pattern3(a,b);
     pattern4(c,d);
    return 0;
}
void pattern1(int i,int j){
    int n;
    printf("Enter number of rows:");
    scanf("%d",&n);
       for(int i=1;i<=n;i++){
       for(int j=1;j<=i;j++){
           printf("!");
       }
       printf("\n");
   }
}
void pattern2(int k,int l){
    int n;
       for(int k=n;k>=1;--k){
       for(int l=1;l<=k;l++){
           printf("!");
       }
       printf("\n");
   }
}
void pattern3(int i,int j){
    int n;
    printf("Enter symbol or (q to quite):");
    scanf("%d",&n);
       for(int i=1;i<=n;i++){
       for(int j=1;j<=i;j++){
           printf("^");
       }
       printf("\n");
   }
}
void pattern4(int k,int l){
    int n;
       for(int k=n;k>=1;--k){
       for(int l=1;l<=k;l++){
           printf("^");
       }
       printf("\n");
   }
}
