#include <stdio.h>
#include <math.h>
void pattern(int,int);
int main()
{
   int a,b;
   pattern(a,b);
    return 0;
}
void pattern(int i,int j){
       for(int i=5;i>=1;--i){
       for(int j=1;j<=i;j++){
           printf("*");
       }
       printf("\n");
   }
}
