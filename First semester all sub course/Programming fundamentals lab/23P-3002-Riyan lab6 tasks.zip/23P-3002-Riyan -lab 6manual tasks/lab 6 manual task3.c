#include <stdio.h>
#include <stdlib.h>

int scoreofSub(int);
int main()
{
    int score;
    printf("Enter your subject score\n");
    scanf("%d",&score);
    scoreofSub(score);
    return 0;
}
int scoreofSub(int score){
     if(score>=90) {
        printf("A+");
    }
     else
        if(score>=80&& score<89){
        printf("A");
    }
     else
        if(score>=70&& score<79){
         printf("B");
    }
    else
        if(score>=60&& score<69){
       printf("C");
    }
    else
        if(score>=50&& score<59){
        printf("D");
    }
    else
    if(score<50){
        printf("F");
    }

}
