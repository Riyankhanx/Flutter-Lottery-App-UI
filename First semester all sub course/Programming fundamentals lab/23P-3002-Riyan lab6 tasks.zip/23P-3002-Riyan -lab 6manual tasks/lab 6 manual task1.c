#include <stdio.h>

int checkage(int);
int main()
{
  int age;
  printf("Please enter your age\n");
  scanf("%d",&age);
  checkage(age);

    return 0;
}
int checkage(int age){
if(age>=18){
    printf("You are old enough to  cast your vote\n");
}
else

if(age<18){
    printf("You are not eligible to cast your vote ,you are now a child\n");
}

}
