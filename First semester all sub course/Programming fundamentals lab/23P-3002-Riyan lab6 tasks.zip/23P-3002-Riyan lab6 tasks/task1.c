#include<stdio.h>

float area_of_circle(float);
float area_of_triangle(float,float);

int main(){
float r;
float  b,h;
printf("Enter value of radius\n");
scanf("%f",&r);
printf("Enter value of base and height\n");
scanf("%f %f",&b,&h);
area_of_circle(r);
area_of_triangle(b,h);
}
float area_of_circle(float r){
float pi=3.1415;
float area1=0;
area1= pi*r*r;
printf("\nArea of given circle is %.1f",area1);
}
float area_of_triangle(float b,float h){
float area2=0;
area2= 0.5*b*h;
printf("\nArea of given triangle is %.0f",area2);
}
