#include <stdio.h>

int max(int,int);

int main()
{
    int x,y;
    printf("Enter value of x and y \n");
    scanf("%d%d",&x,&y);
    max(x,y);

    return 0;
}
int max(int x,int y){

if(x>y){
   printf("%d is maximum\n",x);
}
else{
  printf("%d is maximum\n",y);
}

}
