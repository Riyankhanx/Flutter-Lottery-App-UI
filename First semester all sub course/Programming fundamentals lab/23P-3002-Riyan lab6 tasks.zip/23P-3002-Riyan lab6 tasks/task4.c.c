#include <stdio.h>

float rcharges(int,float);

int main()
{
    int days;
    float miles;
    printf("Enter number of days car is rented\n");
    scanf("%d",&days);
    printf("Enter number of miles a car is driven\n");
    scanf("%f",&miles);

    rcharges(days,miles);

    return 0;
}
float rcharges(int days,float miles){

float base_fee=25.00;
float per_miles=0.15,totalcost=0;
totalcost=base_fee *days + per_miles*miles;

if(days>30)
    {
    totalcost=totalcost*0.8;
}
else
if(days<15)
    {
    totalcost=totalcost+1.99*(15-days);
}
printf("The total rental cost of car is $%.2f\n",totalcost);
}
