#include <stdio.h>

float calculateAttendance(float,float);

int main(void)
{
    float classesS,classesT;
    calculateAttendance(classesS,classesT);

    return 0;
}
float calculateAttendance(float classesAttended,float classesTotal){
float classesS,classesT;
float percentage=0;
   printf("Enter total classes sheduled ");
    scanf("%f",&classesS);
    printf("Enter total classes attended ");
    scanf("%f",&classesT);
percentage=(classesT/classesS)*100;
printf("Your percentage is %.0f\n",percentage);
if(percentage>80){
    printf("You are allowed to sit in the exam");

}
else
if(percentage<80 ||percentage>70)
{
printf("You are  not allowed to sit in the exam");
}
}


