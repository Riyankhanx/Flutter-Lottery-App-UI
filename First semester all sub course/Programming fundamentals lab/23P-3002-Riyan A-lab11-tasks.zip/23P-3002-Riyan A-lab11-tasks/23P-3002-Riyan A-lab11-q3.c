#include <stdio.h>
void Quizz(int[100][100]);
int main() {
int teta[100][100];
Quizz(teta[100][100]);
    return 0;
}
void Quizz(int[100][100])
{
int num_of_Students,numQuizzes;
int i,j;
    printf("Enter the number of students: ");
    scanf("%d",&num_of_Students);
    if (num_of_Students<= 0||num_of_Students>100) {
        printf("Invalid number of students. Exiting...\n");
        return 1;
    }

    printf("Enter the number of quizzes: ");
    scanf("%d",&numQuizzes);

    if (numQuizzes<=0||numQuizzes>100) {
        printf("Invalid number of quizzes. Exiting...\n");
        return 1;
    }
    int scores[100][100];

    for (int i=0;i<num_of_Students;i++) {
        printf("Enter scores for student %d: ",i+1);
        for (int j=0;j<numQuizzes; j++) {
            scanf("%d", &scores[i][j]);
        }
    }
    int quizTotal[100]={0};
    int studentTotal[100]={0};
    for (int j=0;j<numQuizzes;j++) {
        for (int i=0;i<num_of_Students;i++) {
            quizTotal[j]+=scores[i][j];
            studentTotal[i]+=scores[i][j];
        }
    }
    for (int j=0;j<numQuizzes;j++) {
        printf("\nAverage score for quiz %d:%.2f",j +1,(float)quizTotal[j]/num_of_Students);
    }
    for (int i=0;i<num_of_Students;i++) {
         printf("\nAverage score of student %d: %.2f",i+1, (float)studentTotal[i]/numQuizzes);
    }
    float classAverage=0.0;
    for (int i=0;i<num_of_Students;i++) {
        for (int j=0;j<numQuizzes;j++) {
            classAverage=classAverage+scores[i][j];
        }
    }
    classAverage=classAverage/(num_of_Students*numQuizzes);
    printf("\nOverall Class Average: %.2f\n", classAverage);

    int highestScore=scores[0][0];
    for (int i =0;i<num_of_Students;i++) {
        for (int j=0;j<numQuizzes;j++) {
            if (scores[i][j]>highestScore) {
                highestScore=scores[i][j];
            }
        }
    }
    printf("\nHighest Score: %d\n",highestScore);
}



