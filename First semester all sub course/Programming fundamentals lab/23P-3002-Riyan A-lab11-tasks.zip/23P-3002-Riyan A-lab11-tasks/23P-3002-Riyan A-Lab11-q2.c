#include <stdio.h>
void Transpose(int[4][4]);
int main() {
int matrix[4][4];
Transpose(matrix[4][4]);
    return 0;
}
void Transpose(int Func_matrix[4][4]){
        int O_Matrix[4][4]={1,2,3,4, 5,6,7,8,9,10,11,12,13,14,15,16};
    printf("Original matrix:\n");
    for (int i =0;i<4;i++) {
        for (int j=0;j<4;j++) {
            printf("%d ",O_Matrix[i][j]);
        }
        printf("\n");
    }
    int transpose_Matrix[4][4];
    for (int i =0;i<4;i++) {
        for (int j=0;j<4;j++) {
           transpose_Matrix[i][j]=O_Matrix[j][i];
        }
    }
    printf("Transpose of the matrix:\n");
    for (int i =0;i<4;i++) {
        for (int j=0;j<4;j++) {
            printf("%d ",transpose_Matrix[i][j]);
        }
        printf("\n");
    }
}



