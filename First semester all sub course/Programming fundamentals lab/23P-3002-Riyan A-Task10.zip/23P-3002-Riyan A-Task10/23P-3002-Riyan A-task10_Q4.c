#include<stdio.h>
void Array(int[]);
int main(){
    int i;
    Array(i);
    return 0;
}
void Array(int result[10]){
 int i,j;
    printf("Elements before shorting is:10 9 8 7 6 5 4 3 2 1");
int ascendingArray[]={10,9,8,7,6,5,4,3,2,1},swap;
for(int i=0;i<10;i++){

    for(int j=i+1;j<10;j++){
        if(ascendingArray[i]>ascendingArray[j]){

            swap=ascendingArray[i];
            ascendingArray[i]=ascendingArray[j];
            ascendingArray[j]=swap;
        }
    }
}
    printf("\nArray elements after short is:");
    for(int i=0;i<10;i++){
        printf("%d ",ascendingArray[i]);
    }

}
