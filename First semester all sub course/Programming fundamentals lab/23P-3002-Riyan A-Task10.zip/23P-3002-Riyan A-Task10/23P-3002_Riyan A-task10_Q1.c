// Online C compiler to run C program online
#include <stdio.h>
void SalesC(int);
int main() {
int CAL;
SalesC(CAL);
return 0;
}
void SalesC(int l){

 int sales[7],Total;
 int j;
for(int i=0;i<7;i++){
    printf("Enter the sales for the day :%d\n",i+1);
    scanf("%d",&sales[i]);
}
   for(j=0;j<7;j++){
    Total+=sales[j];
}
    printf("Total sales of the week : $%d",Total);
}
