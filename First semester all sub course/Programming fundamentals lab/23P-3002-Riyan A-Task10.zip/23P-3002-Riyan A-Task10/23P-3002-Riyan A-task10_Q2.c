#include<stdio.h>
int Index_check(int,int);
int  main()
{
    int r,s,result;
    result=Index_check(r,s);
   

    return 0;
}
int Index_check(int p,int q ){
    int n,arr[1000],search,flag=0;
    printf("Enter the number of elements:\n") ;
    scanf("%d",&n);
    printf("Enter the elements\n") ;
    for(int i=0;i<n;i++)
    {
        scanf("%d",&arr[i]) ;
    }
    printf("Enter the element to be searched\n");
    scanf("%d",&search);
    for(int i=0;i<n;i++)
    {
        if(arr[i]==search)
        {
            printf("%d found at index %d \n",search,i);
            flag=1;
            break;
        }
    }
      for(int i=0;i<n;i++)
    {
        if(arr[i]==search)
        {
            printf("%d found at index %d \n",search,i);
            flag=1;
            break;
        }
    }
      for(int i=0;i<n;i++)
    {
        if(arr[i]==search)
        {
            printf("%d found at index %d \n",search,i);
            flag=1;
            break;
        }
    }
    if(flag==0)
    {
        printf("Element %d not found\n",search);
 
    }
}